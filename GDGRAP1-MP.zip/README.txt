Members:	Marcus Leocario
    		Joachim Arguelles

Github Link: https://github.com/dummy-ie/GDGRAP1-MP 